/* ============================================
   Maintenance System
   app.js
============================================ */

"use strict";

/* ============================================
   LOGIN CHECK
============================================ */

(function () {

    const page = window.location.pathname.split("/").pop();

    if (page !== "index.html" && page !== "") {

        const login = localStorage.getItem("login");

        if (login !== "true") {

            window.location.href = "index.html";

        }

    }

})();

/* ============================================
   USERNAME
============================================ */

window.addEventListener("DOMContentLoaded", function () {

    const user = localStorage.getItem("username");

    const el = document.getElementById("username");

    if (el) {

        el.innerHTML = user || "Administrator";

    }

});

/* ============================================
   LOGIN
============================================ */

function login() {

    const username = document.getElementById("username").value.trim();

    const password = document.getElementById("password").value.trim();

    if (username === "") {

        alert("Username harus diisi");

        return;

    }

    if (password === "") {

        alert("Password harus diisi");

        return;

    }

    localStorage.setItem("login", "true");

    localStorage.setItem("username", username);

    window.location.href = "dashboard.html";

}

/* ============================================
   LOGOUT
============================================ */

function logout() {

    if (!confirm("Logout sekarang?")) return;

    localStorage.clear();

    window.location.href = "index.html";

}

/* ============================================
   SIDEBAR ACTIVE
============================================ */

document.addEventListener("DOMContentLoaded", function () {

    const links = document.querySelectorAll(".sidebar a");

    links.forEach(link => {

        if (window.location.href === link.href) {

            link.classList.add("active");

        }

    });

});

/* ============================================
   SEARCH TABLE
============================================ */

function searchTable(inputId, tableId) {

    const keyword = document
        .getElementById(inputId)
        .value
        .toUpperCase();

    const table = document.getElementById(tableId);

    const tr = table.getElementsByTagName("tr");

    for (let i = 1; i < tr.length; i++) {

        const row = tr[i];

        let show = false;

        const td = row.getElementsByTagName("td");

        for (let j = 0; j < td.length; j++) {

            if (td[j].innerText.toUpperCase().indexOf(keyword) > -1) {

                show = true;

            }

        }

        row.style.display = show ? "" : "none";

    }

}

/* ============================================
   FILTER STATUS
============================================ */

function filterStatus(selectId, tableId, columnIndex) {

    const status = document.getElementById(selectId).value;

    const table = document.getElementById(tableId);

    const rows = table.getElementsByTagName("tr");

    for (let i = 1; i < rows.length; i++) {

        const cell = rows[i].getElementsByTagName("td")[columnIndex];

        if (!cell) continue;

        if (status === "") {

            rows[i].style.display = "";

            continue;

        }

        rows[i].style.display =
            cell.innerText.trim().includes(status)
                ? ""
                : "none";

    }

}

/* ============================================
   DELETE
============================================ */

function deleteRow(btn) {

    if (!confirm("Yakin menghapus data?")) {

        return;

    }

    btn.closest("tr").remove();

    toast("Data berhasil dihapus");

}

/* ============================================
   FORMAT RUPIAH
============================================ */

function rupiah(angka) {

    return new Intl.NumberFormat("id-ID", {

        style: "currency",

        currency: "IDR"

    }).format(angka);

}

/* ============================================
   PREVIEW IMAGE
============================================ */

function previewImage(input, target) {

    if (!input.files.length) return;

    const reader = new FileReader();

    reader.onload = function (e) {

        document.getElementById(target).src = e.target.result;

    }

    reader.readAsDataURL(input.files[0]);

}

/* ============================================
   TOAST
============================================ */

function toast(message) {

    let toast = document.createElement("div");

    toast.className = "toast-custom";

    toast.innerHTML = message;

    document.body.appendChild(toast);

    setTimeout(() => {

        toast.classList.add("show");

    }, 100);

    setTimeout(() => {

        toast.classList.remove("show");

        setTimeout(() => {

            toast.remove();

        }, 300);

    }, 2500);

}

/* ============================================
   LOADER
============================================ */

function showLoader() {

    let loader = document.createElement("div");

    loader.id = "loader";

    loader.innerHTML =

    '<div class="spinner-border text-primary"></div>';

    document.body.appendChild(loader);

}

function hideLoader() {

    let loader = document.getElementById("loader");

    if (loader) loader.remove();

}

/* ============================================
   DATE NOW
============================================ */

function today() {

    let d = new Date();

    return d.toISOString().substring(0,10);

}

/* ============================================
   AUTO DATE
============================================ */

window.addEventListener("DOMContentLoaded",function(){

    let input=document.querySelectorAll(".today");

    input.forEach(function(i){

        i.value=today();

    });

});

/* ============================================
   RANDOM ORDER NUMBER
============================================ */

function generateOrderNumber(){

    let n=Math.floor(Math.random()*99999);

    return "ORD-"+String(n).padStart(5,"0");

}

/* ============================================
   PAGINATION DUMMY
============================================ */

function pagination(){

    console.log("Pagination Loaded");

}

/* ============================================
   EXPORT CSV (Dummy)
============================================ */

function exportCSV(){

    alert("Export CSV berhasil (dummy)");

}

/* ============================================
   PRINT
============================================ */

function printPage(){

    window.print();

}

/* ============================================
   APPROVE
============================================ */

function approve(){

    toast("Order berhasil diapprove");

}

/* ============================================
   REJECT
============================================ */

function reject(){

    toast("Order ditolak");

}

/* ============================================
   FINISH
============================================ */

console.log("Maintenance System Ready");